package com.example.quickmacro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Tekan tombol di bawah, lalu aktifkan 'Quick Macro' di Aksesibilitas.\n\n" +
                "2. Panel melayang muncul di tepi layar:\n" +
                "   • REC: mulai rekam. Ketuk/geser di layar untuk menyusun urutan, lalu tekan SAVE.\n" +
                "   • PLAY: putar urutan. Tekan lagi (STOP) untuk berhenti.\n" +
                "   • LOOP: ulangi terus sampai STOP.\n\n" +
                "Gunakan hanya untuk game offline/single-player atau tugas berulang. Di game online, macro bisa melanggar aturan dan membuat akun diblokir."
        })
        root.addView(Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
