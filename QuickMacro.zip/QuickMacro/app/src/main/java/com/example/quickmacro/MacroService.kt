package com.example.quickmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout

data class Act(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val dur: Long, val delay: Long)

class MacroService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var recOverlay: View? = null
    private lateinit var btnRec: Button
    private lateinit var btnPlay: Button
    private lateinit var btnLoop: Button

    private var acts: List<Act> = emptyList()
    private val recording = ArrayList<Act>()
    private var isRecording = false
    private var playing = false
    private var loop = false
    private var lastDownT = 0L

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        acts = load()
        buildPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopPlay() }

    override fun onDestroy() {
        stopPlay()
        recOverlay?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL),
        PixelFormat.TRANSLUCENT
    )

    private fun buildPanel() {
        btnRec = Button(this).apply { text = "REC"; setOnClickListener { toggleRec() } }
        btnPlay = Button(this).apply { text = "PLAY"; setOnClickListener { togglePlay() } }
        btnLoop = Button(this).apply {
            text = "LOOP: OFF"
            setOnClickListener { loop = !loop; text = if (loop) "LOOP: ON" else "LOOP: OFF" }
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(160, 0, 0, 0))
            addView(btnRec); addView(btnPlay); addView(btnLoop)
        }
        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false)
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        wm.addView(panel, lp)
    }

    private fun bringPanelToFront() {
        val p = panel ?: return
        val lp = p.layoutParams
        runCatching { wm.removeView(p) }
        wm.addView(p, lp)
    }

    // ---------- Recording ----------
    private fun toggleRec() {
        if (isRecording) {
            isRecording = false
            recOverlay?.let { runCatching { wm.removeView(it) } }
            recOverlay = null
            if (recording.isNotEmpty()) { acts = recording.toList(); save(acts) }
            btnRec.text = "REC"
        } else {
            stopPlay()
            recording.clear()
            lastDownT = 0L
            isRecording = true
            btnRec.text = "SAVE"
            var dx = 0f; var dy = 0f; var dt = 0L
            val v = View(this).apply {
                setBackgroundColor(Color.argb(40, 255, 0, 0))
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; dt = System.currentTimeMillis() }
                        MotionEvent.ACTION_UP -> {
                            val delay = if (lastDownT == 0L) 0L else dt - lastDownT
                            lastDownT = dt
                            val dur = (System.currentTimeMillis() - dt).coerceAtLeast(1L)
                            recording.add(Act(dx, dy, e.rawX, e.rawY, dur, delay))
                        }
                    }
                    true
                }
            }
            recOverlay = v
            wm.addView(v, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true))
            bringPanelToFront()
        }
    }

    // ---------- Playback ----------
    private fun togglePlay() {
        if (playing) { stopPlay(); return }
        if (isRecording || acts.isEmpty()) return
        playing = true
        btnPlay.text = "STOP"
        runFrom(0)
    }

    private fun stopPlay() {
        playing = false
        handler.removeCallbacksAndMessages(null)
        if (::btnPlay.isInitialized) btnPlay.text = "PLAY"
    }

    private fun runFrom(i: Int) {
        if (!playing) return
        if (i >= acts.size) {
            if (loop) handler.postDelayed({ runFrom(0) }, 100) else stopPlay()
            return
        }
        val a = acts[i]
        handler.postDelayed({
            if (!playing) return@postDelayed
            val path = Path().apply {
                moveTo(a.x1, a.y1)
                if (a.x1 != a.x2 || a.y1 != a.y2) lineTo(a.x2, a.y2)
            }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, a.dur.coerceAtLeast(1)))
                .build()
            dispatchGesture(g, null, null)
            runFrom(i + 1)
        }, a.delay)
    }

    // ---------- Storage ----------
    private fun save(list: List<Act>) {
        val s = list.joinToString(";") { "${it.x1},${it.y1},${it.x2},${it.y2},${it.dur},${it.delay}" }
        getSharedPreferences("macro", MODE_PRIVATE).edit().putString("acts", s).apply()
    }

    private fun load(): List<Act> {
        val s = getSharedPreferences("macro", MODE_PRIVATE).getString("acts", "") ?: ""
        if (s.isEmpty()) return emptyList()
        return s.split(";").mapNotNull {
            val p = it.split(",")
            if (p.size != 6) null else Act(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4].toLong(), p[5].toLong())
        }
    }
}
